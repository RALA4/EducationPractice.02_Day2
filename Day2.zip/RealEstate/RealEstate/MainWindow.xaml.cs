﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using RealEstate.pages;

namespace RealEstate
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            BaseClient.ItemsSource = App.estate.Clients.ToList();
            BaseAgents.ItemsSource = App.estate.Agents.ToList();
            BaseHouses.ItemsSource = App.estate.Houses.ToList();
            BaseLands.ItemsSource = App.estate.Lands.ToList();
            BaseApartment.ItemsSource = App.estate.Apartments.ToList();
            BaseApartmentDemand.ItemsSource = App.estate.ApartmentDemands.ToList();

            CmBSelect.Items.Add("Клиенты");
            CmBSelect.Items.Add("Агенты");
            CmBSelect.Items.Add("Продажа домов");
            CmBSelect.Items.Add("Продажа земли");
            CmBSelect.Items.Add("Продажа квартир");
            CmBSelect.Items.Add("Потребности");
        }

        private void CmBSelect_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CmBSelect.SelectedIndex == 0)
            {
                BaseClient.Visibility = Visibility.Visible;
                BaseAgents.Visibility = Visibility.Hidden;
                BaseHouses.Visibility = Visibility.Hidden;
                BaseLands.Visibility = Visibility.Hidden;
                BaseApartment.Visibility = Visibility.Hidden;
                BaseApartmentDemand.Visibility = Visibility.Hidden;
            }
            if (CmBSelect.SelectedIndex == 1)
            {
                BaseClient.Visibility = Visibility.Hidden;
                BaseAgents.Visibility = Visibility.Visible;
                BaseHouses.Visibility = Visibility.Hidden;
                BaseLands.Visibility = Visibility.Hidden;
                BaseApartment.Visibility = Visibility.Hidden;
                BaseApartmentDemand.Visibility = Visibility.Hidden;
            }
            if (CmBSelect.SelectedIndex == 2)
            {
                BaseClient.Visibility = Visibility.Hidden;
                BaseAgents.Visibility = Visibility.Hidden;
                BaseHouses.Visibility = Visibility.Visible;
                BaseLands.Visibility = Visibility.Hidden;
                BaseApartment.Visibility = Visibility.Hidden;
                BaseApartmentDemand.Visibility = Visibility.Hidden;
            }
            if (CmBSelect.SelectedIndex == 3)
            {
                BaseClient.Visibility = Visibility.Hidden;
                BaseAgents.Visibility = Visibility.Hidden;
                BaseHouses.Visibility = Visibility.Hidden;
                BaseLands.Visibility = Visibility.Visible;
                BaseApartment.Visibility = Visibility.Hidden;
                BaseApartmentDemand.Visibility = Visibility.Hidden;
            }
            if (CmBSelect.SelectedIndex == 4)
            {
                BaseClient.Visibility = Visibility.Hidden;
                BaseAgents.Visibility = Visibility.Hidden;
                BaseHouses.Visibility = Visibility.Hidden;
                BaseLands.Visibility = Visibility.Hidden;
                BaseApartment.Visibility = Visibility.Visible;
                BaseApartmentDemand.Visibility = Visibility.Hidden;
            }
            if (CmBSelect.SelectedIndex == 5)
            {
                BaseClient.Visibility = Visibility.Hidden;
                BaseAgents.Visibility = Visibility.Hidden;
                BaseHouses.Visibility = Visibility.Hidden;
                BaseLands.Visibility = Visibility.Hidden;
                BaseApartment.Visibility = Visibility.Hidden;
                BaseApartmentDemand.Visibility = Visibility.Visible;
            }
        }

        private void AddUser_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (BaseClient.Visibility == Visibility.Visible)
                {
                    ClientAdd clientAdd = new ClientAdd();
                    clientAdd.Show();
                    this.Close();
                }
                else
                {
                    if (BaseAgents.Visibility == Visibility.Visible)
                    {
                        AgentAdd agentAdd = new AgentAdd();
                        agentAdd.Show();
                        this.Close();
                    }
                    else
                    {
                        if(BaseHouses.Visibility == Visibility.Visible)
                        {
                            HomeAdd homeAdd = new HomeAdd();
                            homeAdd.Show();
                            this.Close();
                        }
                        else
                        {
                            if(BaseLands.Visibility == Visibility.Visible)
                            {
                                LandsAdd landsAdd = new LandsAdd();
                                landsAdd.Show();
                                this.Close();
                            }
                            else
                            {
                                if (BaseApartment.Visibility == Visibility.Visible)
                                {
                                    ApartmentAdd apartmentAdd = new ApartmentAdd();
                                    apartmentAdd.Show();
                                    this.Close();
                                }
                                else
                                {
                                    if (BaseApartmentDemand.Visibility == Visibility.Visible)
                                    {
                                        ApartmentDemandAdd apartmentDemandAdd = new ApartmentDemandAdd();
                                        apartmentDemandAdd.Show();
                                        this.Close();
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch 
            {
                MessageBox.Show("Таблица не определена!");
            }
        }

        private void EditUser_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var row1 = BaseClient.SelectedItem as database.Client;
                var row2 = BaseAgents.SelectedItem as database.Agent;
                var row3 = BaseHouses.SelectedItem as database.House;
                var row4 = BaseLands.SelectedItem as database.Land;
                var row5 = BaseApartment.SelectedItem as database.Apartment;
                var row6 = BaseApartmentDemand.SelectedItem as database.ApartmentDemand;
                if (row1 != null | row2 != null | row3 != null | row4 != null | row5 != null | row6 != null)
                {
                    if (BaseClient.Visibility == Visibility.Visible)
                    {
                        ClientEdit clientEdit = new ClientEdit(row1);
                        clientEdit.Show();
                        this.Close();
                    }
                    else
                    {
                        if (BaseAgents.Visibility == Visibility.Visible)
                        {
                            AgentEdit agentEdit = new AgentEdit(row2);
                            agentEdit.Show();
                            this.Close();
                        }
                        else
                        {
                            if (BaseHouses.Visibility == Visibility.Visible)
                            {
                                HomeEdit homeEdit = new HomeEdit(row3);
                                homeEdit.Show();
                                this.Close();
                            }
                            else
                            {
                                if (BaseLands.Visibility == Visibility.Visible)
                                {
                                    LandsEdit landsEdit = new LandsEdit(row4);
                                    landsEdit.Show();
                                    this.Close();
                                }
                                else
                                {
                                    if (BaseApartment.Visibility == Visibility.Visible)
                                    {
                                        ApartmentEdit apartmentEdit = new ApartmentEdit(row5);
                                        apartmentEdit.Show();
                                        this.Close();
                                    }
                                    else
                                    {
                                        if (BaseApartmentDemand.Visibility == Visibility.Visible)
                                        {
                                            ApartmentDemandEdit apartmentDemandEdit = new ApartmentDemandEdit(row6);
                                            apartmentDemandEdit.Show();
                                            this.Close();

                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Строка не выбрана для редактирования!!");
                }
            }
            catch
            {
                MessageBox.Show("Строка не выбрана для редактирования!!");
            }
        }

        private void DeleteUser_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var row1 = BaseClient.SelectedItem as database.Client;
                var row2 = BaseAgents.SelectedItem as database.Agent;
                var row3 = BaseHouses.SelectedItem as database.House;
                var row4 = BaseLands.SelectedItem as database.Land;
                var row5 = BaseApartment.SelectedItem as database.Apartment;
                var row6 = BaseApartmentDemand.SelectedItem as database.ApartmentDemand;

                if (row1 != null | row2 != null | row3 != null | row4 != null | row5 != null | row6 != null)
                {
                    if (BaseClient.Visibility == Visibility.Visible)
                    {
                        MessageBoxResult message = MessageBox.Show("Вы уверены, что хотите удалить данную строку?", "Предупреждение",
                            MessageBoxButton.YesNo, MessageBoxImage.Question);
                        if (message == MessageBoxResult.Yes)
                        {
                            App.estate.Clients.Remove(row1);
                            App.estate.SaveChanges();
                            MessageBox.Show("Строка успешно удалена!");
                            MainWindow firstWindow = new MainWindow();
                            firstWindow.Show();
                            this.Close();
                        }
                    }
                    else
                    {
                        if (BaseAgents.Visibility == Visibility.Visible)
                        {
                            MessageBoxResult message = MessageBox.Show("Вы уверены, что хотите удалить данную строку?", "Предупреждение",
                            MessageBoxButton.YesNo, MessageBoxImage.Question);
                            if (message == MessageBoxResult.Yes)
                            {
                                App.estate.Agents.Remove(row2);
                                App.estate.SaveChanges();
                                MessageBox.Show("Строка успешно удалена!");
                                MainWindow firstWindow = new MainWindow();
                                firstWindow.Show();
                                this.Close();
                            }
                        }
                        else
                        {
                            if (BaseHouses.Visibility == Visibility.Visible)
                            {
                                MessageBoxResult message = MessageBox.Show("Вы уверены, что хотите удалить данную строку?", "Предупреждение",
                                MessageBoxButton.YesNo, MessageBoxImage.Question);
                                if (message == MessageBoxResult.Yes)
                                {
                                    App.estate.Houses.Remove(row3);
                                    App.estate.SaveChanges();
                                    MessageBox.Show("Строка успешно удалена!");
                                    MainWindow firstWindow = new MainWindow();
                                    firstWindow.Show();
                                    this.Close();
                                }
                            }
                            else
                            {
                                if (BaseLands.Visibility == Visibility.Visible)
                                {
                                    MessageBoxResult message = MessageBox.Show("Вы уверены, что хотите удалить данную строку?", "Предупреждение",
                                    MessageBoxButton.YesNo, MessageBoxImage.Question);
                                    if (message == MessageBoxResult.Yes)
                                    {
                                        App.estate.Lands.Remove(row4);
                                        App.estate.SaveChanges();
                                        MessageBox.Show("Строка успешно удалена!");
                                        MainWindow firstWindow = new MainWindow();
                                        firstWindow.Show();
                                        this.Close();
                                    }
                                }
                                else
                                {
                                    if (BaseApartment.Visibility == Visibility.Visible)
                                    {
                                        MessageBoxResult message = MessageBox.Show("Вы уверены, что хотите удалить данную строку?", "Предупреждение",
                                        MessageBoxButton.YesNo, MessageBoxImage.Question);
                                        if (message == MessageBoxResult.Yes)
                                        {
                                            App.estate.Apartments.Remove(row5);
                                            App.estate.SaveChanges();
                                            MessageBox.Show("Строка успешно удалена!");
                                            MainWindow firstWindow = new MainWindow();
                                            firstWindow.Show();
                                            this.Close();
                                        }
                                    }
                                    else
                                    {
                                        if (BaseApartmentDemand.Visibility == Visibility.Visible)
                                        {
                                            MessageBoxResult message = MessageBox.Show("Вы уверены, что хотите удалить данную строку?", "Предупреждение",
                                            MessageBoxButton.YesNo, MessageBoxImage.Question);
                                            if (message == MessageBoxResult.Yes)
                                            {
                                                App.estate.ApartmentDemands.Remove(row6);
                                                App.estate.SaveChanges();
                                                MessageBox.Show("Строка успешно удалена!");
                                                MainWindow firstWindow = new MainWindow();
                                                firstWindow.Show();
                                                this.Close();
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Строка не выбрана для редактирования!!");
                }
            }
            catch
            {
                MessageBox.Show("Строка не выбрана для редактирования!!");
            }
        }

        private void Search_TextChanged(object sender, TextChangedEventArgs e)
        {
            try
            {
                if (BaseClient.Visibility == Visibility.Visible)
                {
                    var searchClient = App.estate.Clients.Where(x => x.FirstName.Contains(Search.Text) 
                    | x.MiddleName.Contains(Search.Text) | x.LastName.Contains(Search.Text)).ToList();
                    BaseClient.ItemsSource = searchClient;
                }
                else
                {
                    if (BaseAgents.Visibility == Visibility.Visible)
                    {
                        var searchAgent = App.estate.Agents.Where(x => x.FirstName.Contains(Search.Text)
                        | x.MiddleName.Contains(Search.Text) | x.LastName.Contains(Search.Text)).ToList();
                        BaseClient.ItemsSource = searchAgent;
                    }
                    else
                    {
                        MessageBox.Show("Ничего не найденно!");
                    }
                }
            }
            catch
            {
                MessageBox.Show("Не определена таблица!");
            }
        }
    }
}
