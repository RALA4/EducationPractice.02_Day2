﻿using RealEstate.database;
using System;
using System.Collections.Generic;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RealEstate.pages
{
    /// <summary>
    /// Логика взаимодействия для LandsEdit.xaml
    /// </summary>
    public partial class LandsEdit : Window
    {
        database.Land land;
        public LandsEdit(database.Land land)
        {
            InitializeComponent();
            cbDistrict.ItemsSource = App.estate.Districts.Select(x => x.Name).ToList();
            this.land = land;
            this.DataContext = land;
            identity = land.idLands;
            List<Land> lands = App.estate.Lands.Where(x => x.idLands == identity).ToList();
        }
        int identity;

        private void EditBlock_Click(object sender, RoutedEventArgs e)//Редактирование
        {
            try
            {
                if (tbCity.Text == "" | tbStreet.Text == "" | cbDistrict.Text == "" | tbNumberHouse.Text == "" | tbTotalArea.Text == "")
                {
                    MessageBox.Show("Заполните все поля!");
                }
                else
                {
                    int idDis = App.estate.Districts.Where(x => x.Name == cbDistrict.Text).Select(x => x.idDistricts).FirstOrDefault();
                    List<Land> lands = App.estate.Lands.Where(x => x.idLands == identity).ToList();
                    try
                    {
                        lands[0].Address_City = tbCity.Text;
                        lands[0].Address_Street = tbStreet.Text;
                        lands[0].id_Districts = idDis;
                        lands[0].Address_Number = Convert.ToInt32(tbNumberHouse.Text);
                        lands[0].TotalArea = tbTotalArea.Text;
                    }
                    catch { }
                    App.estate.Lands.AddOrUpdate();
                    App.estate.SaveChanges();
                    MessageBox.Show("Данные успешно изменены!");
                    MainWindow firstWindow = new MainWindow();
                    firstWindow.Show();
                    this.Close();
                }
            }
            catch 
            {
                MessageBox.Show("Одна из строк имела неверный формат!\nПроверьте чтобы 'Номер квартиры' не содержал буквы!");
            }
        }

        private void Exit_Click(object sender, RoutedEventArgs e)//Выход
        {
            MainWindow firstWindow = new MainWindow();
            firstWindow.Show();
            this.Close();
        }

        private void tbNumberHouse_PreviewKeyDown(object sender, KeyEventArgs e)//Запрет на ввод букв
        {
            if ((e.Key < Key.D0 | e.Key > Key.D9) & (e.Key < Key.NumPad0 |
                e.Key > Key.NumPad9) & e.Key != Key.Back & e.Key != Key.OemComma)
            {
                e.Handled = true;
            }
        }
    }
}
