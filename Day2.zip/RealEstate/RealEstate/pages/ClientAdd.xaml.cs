﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RealEstate.pages
{
    /// <summary>
    /// Логика взаимодействия для ClientAdd.xaml
    /// </summary>
    public partial class ClientAdd : Window
    {
        public ClientAdd()
        {
            InitializeComponent();
        }

        private void AddUser_Click(object sender, RoutedEventArgs e)//Добавление клиента
        {
            try
            {
                if (tbFirstName.Text == "" | tbName.Text == "" | tbSecondName.Text == "" | tbPhone.Text == "" | tbEmail.Text == "")
                {
                    MessageBox.Show("Заполните все поля!");
                }
                else
                {
                    database.EP02_Day1Entities1 db = new database.EP02_Day1Entities1();
                    database.Client client = new database.Client()
                    {
                        FirstName = tbFirstName.Text,
                        MiddleName = tbName.Text,
                        LastName = tbSecondName.Text,
                        Phone = tbPhone.Text,
                        Email = tbEmail.Text
                    };
                    db.Clients.Add(client);
                    db.SaveChanges();
                    MessageBox.Show("Данные успешно сохранены!");
                    MainWindow firstWindow = new MainWindow();
                    firstWindow.Show();
                    this.Close();
                }
            }
            catch
            {
                MessageBox.Show("Одна из строк имела неверный формат!");
            }
        }

        private void Exit_Click(object sender, RoutedEventArgs e)//Выход
        {
            MainWindow firstWindow = new MainWindow();
            firstWindow.Show();
            this.Close();
        }
    }
}
