﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RealEstate.pages
{
    /// <summary>
    /// Логика взаимодействия для ApartmentDemandAdd.xaml
    /// </summary>
    public partial class ApartmentDemandAdd : Window
    {
        public ApartmentDemandAdd()
        {
            InitializeComponent();
            cbDistrict.ItemsSource = App.estate.Districts.Select(x => x.Name).ToList();
            cbIDAgent.ItemsSource = App.estate.Agents.Select(x=>x.FirstName).ToList();
            cbIDClient.ItemsSource = App.estate.Clients.Select(x => x.FirstName).ToList();
        }
        private void AddBlock_Click(object sender, RoutedEventArgs e)//Добавление
        {
            try
            {
                database.EP02_Day1Entities1 db = new database.EP02_Day1Entities1();
                int idDis = App.estate.Districts.Where(x => x.Name == cbDistrict.Text).Select(x => x.idDistricts).FirstOrDefault();
                int idAgents = App.estate.Agents.Where(x => x.FirstName == cbIDAgent.Text).Select(x => x.IdAgents).FirstOrDefault();
                int idClients = App.estate.Clients.Where(x => x.FirstName == cbIDClient.Text).Select(x => x.idClient).FirstOrDefault();
                if (cbThisHouse.IsChecked == true)
                {
                    database.ApartmentDemand apartmentDemand = new database.ApartmentDemand()
                    {
                        id_Apartment = null,
                        id_Houses = Convert.ToInt32(cbObject.Text),
                        id_Districts = idDis,
                        id_Lands = null,
                        MinPrice = Convert.ToInt32(tbMinPrice.Text),
                        MaxPrice = Convert.ToInt32(tbMaxPrice.Text),
                        AgentId = idAgents,
                        ClientId = idClients,
                        MinArea = Convert.ToDouble(tbMinArea.Text),
                        MaxArea = Convert.ToDouble(tbMaxArea.Text),
                        MinRooms = Convert.ToInt32(tbMinRooms.Text),
                        MaxRooms = Convert.ToInt32(tbMaxRooms.Text),
                        MinFloor = Convert.ToInt32(tbMinFloor.Text),
                        MaxFloor = Convert.ToInt32(tbMaxFloor.Text)
                    };
                    db.ApartmentDemands.Add(apartmentDemand);
                    db.SaveChanges();
                    MessageBox.Show("Данные успешно сохранены!");
                    MainWindow firstWindow = new MainWindow();
                    firstWindow.Show();
                    this.Close();
                }
                else
                {
                    if (cbThisLand.IsChecked == true)
                    {
                        database.ApartmentDemand apartmentDemand = new database.ApartmentDemand()
                        {
                            id_Apartment = null,
                            id_Houses = null,
                            id_Districts = idDis,
                            id_Lands = Convert.ToInt32(cbObject.Text),
                            MinPrice = Convert.ToInt32(tbMinPrice.Text),
                            MaxPrice = Convert.ToInt32(tbMaxPrice.Text),
                            AgentId = idAgents,
                            ClientId = idClients,
                            MinArea = Convert.ToDouble(tbMinArea.Text),
                            MaxArea = Convert.ToDouble(tbMaxArea.Text),
                            MinRooms = Convert.ToInt32(tbMinRooms.Text),
                            MaxRooms = Convert.ToInt32(tbMaxRooms.Text),
                            MinFloor = Convert.ToInt32(tbMinFloor.Text),
                            MaxFloor = Convert.ToInt32(tbMaxFloor.Text)
                        };
                        db.ApartmentDemands.Add(apartmentDemand);
                        db.SaveChanges();
                        MessageBox.Show("Данные успешно сохранены!");
                        MainWindow firstWindow = new MainWindow();
                        firstWindow.Show();
                        this.Close();
                    }
                    else
                    {
                        if (cbThisApartment.IsChecked == true)
                        {
                            database.ApartmentDemand apartmentDemand = new database.ApartmentDemand()
                            {
                                id_Apartment = Convert.ToInt32(cbObject.Text),
                                id_Houses = null,
                                id_Districts = idDis,
                                id_Lands = null,
                                MinPrice = Convert.ToInt32(tbMinPrice.Text),
                                MaxPrice = Convert.ToInt32(tbMaxPrice.Text),
                                AgentId = idAgents,
                                ClientId = idClients,
                                MinArea = Convert.ToDouble(tbMinArea.Text),
                                MaxArea = Convert.ToDouble(tbMaxArea.Text),
                                MinRooms = Convert.ToInt32(tbMinRooms.Text),
                                MaxRooms = Convert.ToInt32(tbMaxRooms.Text),
                                MinFloor = Convert.ToInt32(tbMinFloor.Text),
                                MaxFloor = Convert.ToInt32(tbMaxFloor.Text)
                            };
                            db.ApartmentDemands.Add(apartmentDemand);
                            db.SaveChanges();
                            MessageBox.Show("Данные успешно сохранены!");
                            MainWindow firstWindow = new MainWindow();
                            firstWindow.Show();
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Выберите объект!");
                        }
                    }
                }
            }
            catch
            {
                MessageBox.Show("Одна из строк имела неверный формат или не все поля заполнены!");
            }

        }

        private void Exit_Click(object sender, RoutedEventArgs e)//Выход
        {
            MainWindow firstWindow = new MainWindow();
            firstWindow.Show();
            this.Close();
        }
        
        private void cbThisHouse_Checked(object sender, RoutedEventArgs e)//Выбор дома
        {
            cbObject.ItemsSource = App.estate.Houses.Select(x => x.idHouse).ToList();
            cbThisHouse.IsChecked = true;
            cbThisLand.IsChecked = false;
            cbThisApartment.IsChecked = false;
        }

        private void cbThisLand_Checked(object sender, RoutedEventArgs e)//Выбор земли
        {
            cbObject.ItemsSource = App.estate.Lands.Select(x => x.idLands).ToList();
            cbThisHouse.IsChecked = false;
            cbThisLand.IsChecked = true;
            cbThisApartment.IsChecked = false;
        }

        private void cbThisApartment_Checked(object sender, RoutedEventArgs e)//Выбор квартиры
        {
            cbObject.ItemsSource = App.estate.Apartments.Select(x => x.IdApartments).ToList();
            cbThisHouse.IsChecked = false;
            cbThisLand.IsChecked = false;
            cbThisApartment.IsChecked = true;
        }

        private void tbMinPrice_PreviewKeyDown(object sender, KeyEventArgs e)//Запрет на Буквы
        {
            if ((e.Key < Key.D0 | e.Key > Key.D9) & (e.Key < Key.NumPad0 | 
                e.Key > Key.NumPad9) & e.Key != Key.Back & e.Key != Key.OemComma)
            {
                e.Handled = true;
            }
        }
    }
}
