﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RealEstate.pages
{
    /// <summary>
    /// Логика взаимодействия для AgentAdd.xaml
    /// </summary>
    public partial class AgentAdd : Window
    {
        public AgentAdd()
        {
            InitializeComponent();
        }

        private void AddUser_Click(object sender, RoutedEventArgs e)//Добавление агента
        {
            try
            {
                if (tbFirstName.Text == "" | tbName.Text == "" | tbSecondName.Text == "" | tbDealShare.Text == "")
                {
                    MessageBox.Show("Заполните все поля!");
                }
                else
                {

                    database.EP02_Day1Entities1 db = new database.EP02_Day1Entities1();
                    database.Agent agent = new database.Agent()
                    {
                        FirstName = tbFirstName.Text,
                        MiddleName = tbName.Text,
                        LastName = tbSecondName.Text,
                        DealShare = Convert.ToInt32(tbDealShare.Text)
                    };
                    db.Agents.Add(agent);
                    db.SaveChanges();
                    MessageBox.Show("Данные успешно сохранены!");
                    MainWindow firstWindow = new MainWindow();
                    firstWindow.Show();
                    this.Close();
                }
            }
            catch
            {
                MessageBox.Show("Одна из строк имела неверный формат!\nПроверьте что процент сделки не содержит букв!");
            }
        }

        private void Exit_Click(object sender, RoutedEventArgs e)//Выход
        {
            MainWindow firstWindow = new MainWindow();
            firstWindow.Show();
            this.Close();
        }
    }
}
