﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RealEstate.pages
{
    /// <summary>
    /// Логика взаимодействия для ApartmentAdd.xaml
    /// </summary>
    public partial class ApartmentAdd : Window
    {
        public ApartmentAdd()
        {
            InitializeComponent();
            cbDistrict.ItemsSource = App.estate.Districts.Select(x => x.Name).ToList();
        }

        private void AddBlock_Click(object sender, RoutedEventArgs e)//Добавление
        {
            try
            {
                if (tbCity.Text == "" | tbStreet.Text == "" | cbDistrict.Text == "" | tbNumberHouse.Text == "" | tbTotalArea.Text == "" | tbRooms.Text == "" | tbFloor.Text == "")
                {
                    MessageBox.Show("Заполните все поля!");
                }
                else
                {
                    int idDis = App.estate.Districts.Where(x => x.Name == cbDistrict.Text).Select(x => x.idDistricts).FirstOrDefault();
                    database.EP02_Day1Entities1 db = new database.EP02_Day1Entities1();
                    database.Apartment apartment = new database.Apartment()
                    {
                        Address_City = tbCity.Text,
                        Address_Street = tbStreet.Text,
                        id_Districts = idDis,
                        Address_Number = Convert.ToInt32(tbNumberHouse.Text),
                        TotalArea = tbTotalArea.Text,
                        Rooms = Convert.ToInt32(tbRooms.Text),
                        Floor = Convert.ToInt32(tbFloor.Text)
                    };
                    db.Apartments.Add(apartment);
                    db.SaveChanges();
                    MessageBox.Show("Данные успешно сохранены!");
                    MainWindow firstWindow = new MainWindow();
                    firstWindow.Show();
                    this.Close();
                }
            }
            catch
            {
                MessageBox.Show("Одна из строк имела неверный формат!\nПроверьте чтобы 'Номер квартиры', 'Количество комнат' и 'Этаж' не содержали буквы!");
            }
        }

        private void Exit_Click(object sender, RoutedEventArgs e)//Выход
        {
            MainWindow firstWindow = new MainWindow();
            firstWindow.Show();
            this.Close();
        }

        private void tbNumberHouse_PreviewKeyDown(object sender, KeyEventArgs e)//Запрет на ввод букв 
        {
            if ((e.Key < Key.D0 | e.Key > Key.D9) & (e.Key < Key.NumPad0 |
                e.Key > Key.NumPad9) & e.Key != Key.Back & e.Key != Key.OemComma)
            {
                e.Handled = true;
            }
        }
    }
}
