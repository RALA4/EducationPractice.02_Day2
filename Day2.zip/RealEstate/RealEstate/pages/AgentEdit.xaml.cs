﻿using RealEstate.database;
using System;
using System.Collections.Generic;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RealEstate.pages
{
    /// <summary>
    /// Логика взаимодействия для AgentEdit.xaml
    /// </summary>
    public partial class AgentEdit : Window
    {
        database.Agent agent;
        public AgentEdit(database.Agent agent)
        {
            InitializeComponent();
            this.agent = agent;
            this.DataContext = agent;
            identity = agent.IdAgents;
            List<Agent> agents = App.estate.Agents.Where(x=>x.IdAgents == identity).ToList();
        }
        int identity;

        private void EditUser_Click(object sender, RoutedEventArgs e)//Добавление агента
        {
            try
            {
                if (tbFirstName.Text == "" | tbName.Text == "" | tbSecondName.Text == "" | tbDealShare.Text == "")
                {
                    MessageBox.Show("Заполните все поля!");
                }
                else
                {

                    List<Agent> agents = App.estate.Agents.Where(x => x.IdAgents == identity).ToList();
                    try
                    {
                        agents[0].FirstName = tbFirstName.Text;
                        agents[0].MiddleName = tbName.Text;
                        agents[0].LastName = tbSecondName.Text;
                        agents[0].DealShare = Convert.ToInt32(tbDealShare.Text);

                    }
                    catch { }
                    App.estate.Clients.AddOrUpdate();
                    App.estate.SaveChanges();
                    MessageBox.Show("Данные успешно изменены!");
                    MainWindow firstWindow = new MainWindow();
                    firstWindow.Show();
                    this.Close();
                }
            }
            catch 
            {
                MessageBox.Show("Одна из строк имела неверный формат!\nПроверьте что процент сделки не содержит букв!");
            }
        }

        private void Exit_Click(object sender, RoutedEventArgs e)//Выход
        {
            MainWindow firstWindow = new MainWindow();
            firstWindow.Show();
            this.Close();
        }
    }
}
