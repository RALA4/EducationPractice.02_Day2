﻿using RealEstate.database;
using System;
using System.Collections.Generic;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RealEstate.pages
{
    /// <summary>
    /// Логика взаимодействия для ApartmentDemandEdit.xaml
    /// </summary>
    public partial class ApartmentDemandEdit : Window
    {
        database.ApartmentDemand apartmentDemand1;
        public ApartmentDemandEdit(database.ApartmentDemand apartmentDemand)
        {
            InitializeComponent(); 
            this.apartmentDemand1 = apartmentDemand;
            this.DataContext = apartmentDemand;
            identity = apartmentDemand.idApartment;
            List<ApartmentDemand> apartmentDemands = App.estate.ApartmentDemands.Where(x => x.idApartment == identity).ToList();
            cbDistrict.ItemsSource = App.estate.Districts.Select(x => x.Name).ToList();
            cbIDAgent.ItemsSource = App.estate.Agents.Select(x => x.FirstName).ToList();
            cbIDClient.ItemsSource = App.estate.Clients.Select(x => x.FirstName).ToList();
        }
        int identity;
        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                database.EP02_Day1Entities1 db = new database.EP02_Day1Entities1();
                int idDis = App.estate.Districts.Where(x => x.Name == cbDistrict.Text).Select(x => x.idDistricts).FirstOrDefault();
                int idAgents = App.estate.Agents.Where(x => x.FirstName == cbIDAgent.Text).Select(x => x.IdAgents).FirstOrDefault();
                int idClients = App.estate.Clients.Where(x => x.FirstName == cbIDClient.Text).Select(x => x.idClient).FirstOrDefault();
                if (cbThisHouse.IsChecked == true)
                {
                    List<ApartmentDemand> apartmentDemands = App.estate.ApartmentDemands.Where(x => x.idApartment == identity).ToList();
                    try
                    {
                        apartmentDemands[0].id_Apartment = null;
                        apartmentDemands[0].id_Houses = Convert.ToInt32(cbObject.Text);
                        apartmentDemands[0].id_Districts = idDis;
                        apartmentDemands[0].id_Lands = null;
                        apartmentDemands[0].MinPrice = Convert.ToInt32(tbMinPrice.Text);
                        apartmentDemands[0].MaxPrice = Convert.ToInt32(tbMaxPrice.Text);
                        apartmentDemands[0].AgentId = idAgents;
                        apartmentDemands[0].ClientId = idClients;
                        apartmentDemands[0].MinArea = Convert.ToDouble(tbMinArea.Text);
                        apartmentDemands[0].MaxArea = Convert.ToDouble(tbMaxArea.Text);
                        apartmentDemands[0].MinRooms = Convert.ToInt32(tbMinRooms.Text);
                        apartmentDemands[0].MaxRooms = Convert.ToInt32(tbMaxRooms.Text);
                        apartmentDemands[0].MinFloor = Convert.ToInt32(tbMinFloor.Text);
                        apartmentDemands[0].MaxFloor = Convert.ToInt32(tbMaxFloor.Text);
                    }
                    catch { }
                    db.ApartmentDemands.AddOrUpdate();
                    db.SaveChanges();
                    MessageBox.Show("Данные успешно изменены!");
                    MainWindow firstWindow = new MainWindow();
                    firstWindow.Show();
                    this.Close();
                }
                else
                {
                    if (cbThisLand.IsChecked == true)
                    {
                        List<ApartmentDemand> apartmentDemands = App.estate.ApartmentDemands.Where(x => x.idApartment == identity).ToList();
                        try
                        {
                            apartmentDemands[0].id_Apartment = null;
                            apartmentDemands[0].id_Houses = null;
                            apartmentDemands[0].id_Districts = idDis;
                            apartmentDemands[0].id_Lands = Convert.ToInt32(cbObject.Text);
                            apartmentDemands[0].MinPrice = Convert.ToInt32(tbMinPrice.Text);
                            apartmentDemands[0].MaxPrice = Convert.ToInt32(tbMaxPrice.Text);
                            apartmentDemands[0].AgentId = idAgents;
                            apartmentDemands[0].ClientId = idClients;
                            apartmentDemands[0].MinArea = Convert.ToDouble(tbMinArea.Text);
                            apartmentDemands[0].MaxArea = Convert.ToDouble(tbMaxArea.Text);
                            apartmentDemands[0].MinRooms = Convert.ToInt32(tbMinRooms.Text);
                            apartmentDemands[0].MaxRooms = Convert.ToInt32(tbMaxRooms.Text);
                            apartmentDemands[0].MinFloor = Convert.ToInt32(tbMinFloor.Text);
                            apartmentDemands[0].MaxFloor = Convert.ToInt32(tbMaxFloor.Text);
                        }
                        catch { }
                        db.ApartmentDemands.AddOrUpdate();
                        db.SaveChanges();
                        MessageBox.Show("Данные успешно изменены!");
                        MainWindow firstWindow = new MainWindow();
                        firstWindow.Show();
                        this.Close();
                    }
                    else
                    {
                        if (cbThisApartment.IsChecked == true)
                        {
                            List<ApartmentDemand> apartmentDemands = App.estate.ApartmentDemands.Where(x => x.idApartment == identity).ToList();
                            try
                            {
                                apartmentDemands[0].id_Apartment = Convert.ToInt32(cbObject.Text);
                                apartmentDemands[0].id_Houses = null;
                                apartmentDemands[0].id_Districts = idDis;
                                apartmentDemands[0].id_Lands = null;
                                apartmentDemands[0].MinPrice = Convert.ToInt32(tbMinPrice.Text);
                                apartmentDemands[0].MaxPrice = Convert.ToInt32(tbMaxPrice.Text);
                                apartmentDemands[0].AgentId = idAgents;
                                apartmentDemands[0].ClientId = idClients;
                                apartmentDemands[0].MinArea = Convert.ToDouble(tbMinArea.Text);
                                apartmentDemands[0].MaxArea = Convert.ToDouble(tbMaxArea.Text);
                                apartmentDemands[0].MinRooms = Convert.ToInt32(tbMinRooms.Text);
                                apartmentDemands[0].MaxRooms = Convert.ToInt32(tbMaxRooms.Text);
                                apartmentDemands[0].MinFloor = Convert.ToInt32(tbMinFloor.Text);
                                apartmentDemands[0].MaxFloor = Convert.ToInt32(tbMaxFloor.Text);
                            }
                            catch { }
                            db.ApartmentDemands.AddOrUpdate();
                            db.SaveChanges();
                            MessageBox.Show("Данные успешно изменены!");
                            MainWindow firstWindow = new MainWindow();
                            firstWindow.Show();
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Выберите объект!");
                        }
                    }
                }
            }
            catch
            {
                MessageBox.Show("Одна из строк имела неверный формат или не все поля заполнены!");
            }
        }

        private void EditBlock_Click(object sender, RoutedEventArgs e)
        {
            MainWindow firstWindow = new MainWindow();
            firstWindow.Show();
            this.Close();
        }
    }
}
