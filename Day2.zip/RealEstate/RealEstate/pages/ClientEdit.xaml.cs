﻿using RealEstate.database;
using System;
using System.Collections.Generic;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RealEstate.pages
{
    /// <summary>
    /// Логика взаимодействия для ClientEdit.xaml
    /// </summary>
    public partial class ClientEdit : Window
    {
        database.Client client;
        public ClientEdit(database.Client client)
        {
            InitializeComponent();
            this.client = client;
            this.DataContext = client;
            identity = client.idClient;
            List<Client> clients = App.estate.Clients.Where(x=>x.idClient == identity).ToList();
        }
        int identity;
        private void Exit_Click(object sender, RoutedEventArgs e)//Редактирование клиента
        {
            MainWindow firstWindow = new MainWindow();
            firstWindow.Show();
            this.Close();
        }

        private void EditUser_Click(object sender, RoutedEventArgs e)//Выход
        {
            try
            {
                if (tbFirstName.Text == "" | tbName.Text == "" | tbSecondName.Text == "" | tbPhone.Text == "" | tbEmail.Text == "")
                {
                    MessageBox.Show("Заполните все поля!");
                }
                else
                {
                    List<Client> clients = App.estate.Clients.Where(x => x.idClient == identity).ToList();
                    try
                    {
                        clients[0].FirstName = tbFirstName.Text;
                        clients[0].MiddleName = tbName.Text;
                        clients[0].LastName = tbSecondName.Text;
                        clients[0].Phone = tbPhone.Text;
                        clients[0].Email = tbEmail.Text;
                    }
                    catch { }
                    App.estate.Clients.AddOrUpdate();
                    App.estate.SaveChanges();
                    MessageBox.Show("Данные успешно изменены!");
                    MainWindow firstWindow = new MainWindow();
                    firstWindow.Show();
                    this.Close();
                }
            }
            catch
            {
                MessageBox.Show("Одна из строк имела неверный формат!");
            }
        }
    }
}
